package com.example.UserMicroServices.service.impl;

import com.example.UserMicroServices.entity.Business;
import com.example.UserMicroServices.entity.Follow;
import com.example.UserMicroServices.entity.User;
import com.example.UserMicroServices.repository.BusinessRepo;
import com.example.UserMicroServices.repository.FollowRepo;
import com.example.UserMicroServices.repository.UserRepo;
import com.example.UserMicroServices.service.BusinessService;
import javafx.beans.binding.StringBinding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class BusinessServiceImpl implements BusinessService {

    @Autowired
    BusinessRepo businessRepo;

    @Autowired
    FollowRepo followRepo;

    @Autowired
    UserRepo userRepo;

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public Business save(Business business) {

        return businessRepo.save(business);
    }

    @Override
    public List<Business> findAllBusinessByModeratorId(String moderatorId) {
        List<String> moderatorList=new ArrayList<>();
        List<Business> business=new ArrayList<>();
        List<Business> businessList=businessRepo.findAll();
        for(Business b:businessList)
        {
            moderatorList=b.getModeratorIds();
            if(moderatorList.contains(moderatorId))
                business.add(b);
        }
        return business;
    }

    @Override
    public void addModeratorToBusinessId(String moderatorId, String businessId, String newModerator) {

        try {
            // todo: write native query to handle this scenario in single query
            Optional<Business> business = businessRepo.findById(businessId);
            // todo: handle null pointer expection
            List<String> moderatorList = business.get().getModeratorIds();
           // moderatorList.stream().filter(moderator -> Objects.equals(moderator, newModerator)).collect(Collectors.toList()).size() == 1
            if (moderatorList.contains(moderatorId)) {
                moderatorList.add(newModerator);
                business.get().setModeratorIds(moderatorList);
                businessRepo.save(business.get());
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void addFollower(String followerId, String BusinessId) {
        Follow follow=new Follow();
        Optional<Business> business=businessRepo.findById(BusinessId);
            follow.setFollowerId(followerId);
            follow.setFollowingId(BusinessId);
            follow.setConnection("pending");
            followRepo.save(follow);

    }

    @Override
    public void process(String followerId, String businessId, Boolean isAccepted) {
        if(isAccepted)
        {
            Follow follow=followRepo.findByFollowerIdAndFollowingId(followerId,businessId);
            follow.setConnection("connected");
            follow.setUpdatedDate(new Date());
            followRepo.save(follow);
        }
        else {
            followRepo.deleteByFollowerIdAndFollowingId(followerId,businessId);
        }
    }

    @Override
    public List<User> showFollowers(String businessId) {
        //Optional<Business> business=businessRepo.findById(businessId);
        List<Follow> followList=followRepo.findByFollowingIdAndConnection(businessId,"connected");
        List<User> userList=new ArrayList<>();
        for(Follow f:followList)
        {
            //User user=new User();
            String followerId=f.getFollowerId();
            Optional<User> user=userRepo.findById(followerId);
            userList.add(user.get());
        }
        return userList;
    }

    @Override
    public List<User> showModerators(String businessId) {
        List<User> userList=new ArrayList<>();
        Optional<Business> business=businessRepo.findById(businessId);
        List<String> modIds=business.get().getModeratorIds();
        for(String i:modIds)
        {
            Optional<User> user=userRepo.findById(i);
            if(user!=null)
            {
                userList.add(user.get());
            }

        }
        return userList;
    }

    @Override
    public List<Business> searchBusiness(String searchTerm) {
        Pattern regs = Pattern.compile(searchTerm, Pattern.CASE_INSENSITIVE);
        Query query = new Query();
        query.addCriteria(Criteria.where("businessName").regex(regs));
        List<Business> businessList = mongoTemplate.find(query,Business.class);
        return businessList;
    }

    @Override
    public Boolean isModerator(String businessId, String userId) {
        Optional<Business> business=businessRepo.findById(businessId);
        List<String> moderators=business.get().getModeratorIds();
        if(moderators.contains(userId))
            return true;
        else
            return false;
    }

}
