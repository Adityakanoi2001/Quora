package com.example.UserMicroServices.dto;


import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class DaDto {
    public String actionType;
    public List<String> categories;
    public String platformId;
    public String userId;
    public String postId;
    private LocalDateTime actionTime;
}
